package com.example.dronemanagement.scheduler;

import com.example.dronemanagement.model.Drone;
import com.example.dronemanagement.model.DroneState;
import com.example.dronemanagement.repository.DroneRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import java.util.List;

@Component
public class DroneBatteryScheduler {

    private static final Logger logger = LoggerFactory.getLogger(DroneBatteryScheduler.class);
    private final DroneRepository droneRepository;

    public DroneBatteryScheduler(DroneRepository droneRepository) {
        this.droneRepository = droneRepository;
    }

    @Scheduled(fixedRate = 60000) // Runs every 60 seconds
    public void reduceBattery() {
        List<Drone> drones = droneRepository.findAll();
        logger.info("Starting battery reduction check for all drones...");

        for (Drone drone : drones) {
            if (drone.getState() == DroneState.DELIVERING && drone.getBatteryCapacity() > 5) {
                int newBattery = Math.max(5, drone.getBatteryCapacity() - 5);
                drone.setBatteryCapacity(newBattery);
                droneRepository.save(drone);

                logger.info("Battery reduced for drone {} to {}%", drone.getSerialNumber(), newBattery);
            } else {
                logger.info("Drone {} is not in DELIVERING state or battery is too low ({}%)", 
                            drone.getSerialNumber(), drone.getBatteryCapacity());
            }
        }

        logger.info("Battery reduction check completed.");
    }
}
