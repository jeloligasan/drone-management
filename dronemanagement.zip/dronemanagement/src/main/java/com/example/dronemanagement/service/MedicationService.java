package com.example.dronemanagement.service;

import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import com.example.dronemanagement.model.Drone;
import com.example.dronemanagement.model.Medication;
import com.example.dronemanagement.repository.DroneRepository;
import com.example.dronemanagement.repository.MedicationRepository;

@Service
public class MedicationService {
    private final MedicationRepository medicationRepository;
    private final DroneRepository droneRepository;

    public MedicationService(MedicationRepository medicationRepository, DroneRepository droneRepository) {
        this.medicationRepository = medicationRepository;
        this.droneRepository = droneRepository;
    }

    public String loadMedications(String droneSerial, List<Medication> medications) {
        Optional<Drone> optionalDrone = droneRepository.findById(droneSerial);
        if (optionalDrone.isEmpty()) {
            throw new RuntimeException("Drone not found with serial: " + droneSerial);
        }

        Drone drone = optionalDrone.get();


        double totalWeight = medications.stream().mapToDouble(Medication::getWeight).sum();
        if (totalWeight > drone.getWeightLimit()) {
            throw new RuntimeException("Exceeds drone weight limit!");
        }

        medications.forEach(med -> med.setDrone(drone));
        medicationRepository.saveAll(medications);

        return "Medications loaded successfully";
    }

    public List<Medication> getLoadedMedications(String droneSerial) {
        Optional<Drone> optionalDrone = droneRepository.findById(droneSerial);
        if (optionalDrone.isEmpty()) {
            throw new RuntimeException("Drone not found");
        }
        return medicationRepository.findByDrone(optionalDrone.get());
    }

    public List<Medication> getMedicationsByDrone(String serialNumber) {
        Optional<Drone> optionalDrone = droneRepository.findById(serialNumber);
        if (optionalDrone.isEmpty()) {
            throw new RuntimeException("Drone not found");
        }
        return medicationRepository.findByDrone(optionalDrone.get());
    }
}
