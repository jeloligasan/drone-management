package com.example.dronemanagement.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Pattern;

@Entity
public class Medication {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Pattern(regexp = "^[a-zA-Z0-9-_]+$", message = "Invalid medication name")
    private String name;

    private int weight;

    @Pattern(regexp = "^[A-Z0-9_]+$", message = "Invalid medication code")
    private String code;

    private String imageUrl;

    @ManyToOne
    @JoinColumn(name = "drone_serial")
    private Drone drone;

    public Medication() {}

    public Medication(String name, int weight, String code, String imageUrl, Drone drone) {
        this.name = name;
        this.weight = weight;
        this.code = code;
        this.imageUrl = imageUrl;
        this.drone = drone;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public int getWeight() { return weight; }
    public void setWeight(int weight) { this.weight = weight; }
    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }
    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }
    public Drone getDrone() { return drone; }
    public void setDrone(Drone drone) { this.drone = drone; }
}
