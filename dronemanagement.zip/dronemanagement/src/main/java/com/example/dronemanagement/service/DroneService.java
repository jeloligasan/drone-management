package com.example.dronemanagement.service;

import com.example.dronemanagement.model.Drone;
import com.example.dronemanagement.model.DroneState;
import com.example.dronemanagement.repository.DroneRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DroneService {

    private final DroneRepository droneRepository;

    public DroneService(DroneRepository droneRepository) {
        this.droneRepository = droneRepository;
    }

    public Drone registerDrone(Drone drone) {
        return droneRepository.save(drone);
    }

    public List<Drone> getAvailableDrones() {
        return droneRepository.findByState(DroneState.IDLE);
    }

    public int getBatteryLevel(String serialNumber) {
        Optional<Drone> drone = droneRepository.findById(serialNumber);
        return drone.map(Drone::getBatteryCapacity)
                .orElseThrow(() -> new RuntimeException("Drone not found with serial: " + serialNumber));
    }


    public Drone getDroneBySerialNumber(String serialNumber) {
        return droneRepository.findById(serialNumber)
                .orElseThrow(() -> new RuntimeException("Drone not found with serial: " + serialNumber));
    }


    public Drone updateDrone(Drone drone) {
        return droneRepository.save(drone);
    }
}
