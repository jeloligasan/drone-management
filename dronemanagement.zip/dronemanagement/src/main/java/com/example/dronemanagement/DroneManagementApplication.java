package com.example.dronemanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DroneManagementApplication {
    public static void main(String[] args) {
        SpringApplication.run(DroneManagementApplication.class, args);
    }
}
