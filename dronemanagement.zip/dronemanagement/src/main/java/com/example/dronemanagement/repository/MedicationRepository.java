package com.example.dronemanagement.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.example.dronemanagement.model.Medication;
import com.example.dronemanagement.model.Drone;

public interface MedicationRepository extends JpaRepository<Medication, Long> {
    List<Medication> findByDrone(Drone drone);
}
