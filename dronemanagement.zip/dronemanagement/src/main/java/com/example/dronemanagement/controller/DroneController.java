package com.example.dronemanagement.controller;

import com.example.dronemanagement.model.Drone;
import com.example.dronemanagement.model.DroneState;
import com.example.dronemanagement.service.DroneService;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/drones")
public class DroneController {

    private final DroneService droneService;

    public DroneController(DroneService droneService) {
        this.droneService = droneService;
    }

    @PostMapping("/register")
    public ResponseEntity<Drone> registerDrone(@RequestBody Drone drone) {
        return ResponseEntity.ok(droneService.registerDrone(drone));
    }

    @GetMapping("/available")
    public ResponseEntity<List<Drone>> getAvailableDrones() {
        return ResponseEntity.ok(droneService.getAvailableDrones());
    }

    @GetMapping("/{serialNumber}/battery")
    public ResponseEntity<Integer> getBatteryLevel(@PathVariable String serialNumber) {
        return ResponseEntity.ok(droneService.getBatteryLevel(serialNumber));
    }

    @GetMapping("/{serialNumber}")
    public ResponseEntity<Drone> getDroneBySerialNumber(@PathVariable String serialNumber) {
        return ResponseEntity.ok(droneService.getDroneBySerialNumber(serialNumber));
    }

    @PutMapping("/{serialNumber}/state")
    public ResponseEntity<?> updateDroneState(@PathVariable String serialNumber, @RequestParam DroneState state) {
        try {
            Drone drone = droneService.getDroneBySerialNumber(serialNumber);
            drone.setState(state);
            droneService.updateDrone(drone);
            return ResponseEntity.ok("Drone state updated to " + state);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Drone not found");
        }
    }
}
