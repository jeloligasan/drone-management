package com.example.dronemanagement.model;

public enum DroneModel {
    LIGHTWEIGHT, MIDDLEWEIGHT, CRUISERWEIGHT, HEAVYWEIGHT
}
