package com.example.dronemanagement.repository;

import com.example.dronemanagement.model.Drone;
import com.example.dronemanagement.model.DroneState;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface DroneRepository extends JpaRepository<Drone, String> {
    List<Drone> findByState(DroneState state);
}
