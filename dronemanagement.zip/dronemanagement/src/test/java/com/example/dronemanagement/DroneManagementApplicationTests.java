package com.example.dronemanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DroneManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
